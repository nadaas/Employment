function snsWriteSummonEvent() {
	var summon = false;
	
	$("#snsWriteSummon").click(function() {
		if (!summon) {
			
			var a = $("<input>").attr("type","file").attr("id","snsfileInput").attr("multiple","multiple");
			
			var aa = $("<td></td>");
			aa.append(a);
			var aaa = $("<tr></tr>");
			aaa.append(aa);
			var aaaa =$("<table></table>").attr("id", "snsfileInputTable");
			aaaa.append(aaa);
			
			
			var td1 = $("<td></td>").attr("id","snstabFileName").attr("align","center").text("파일명");
			var td2 = $("<td></td>").attr("id","snstabFileDel").text("삭제");
			var tr = $("<tr></tr>");
			tr.append(td1, td2);
			

			var table = $("<table></table>").attr("id","snsfileTable");
			table.append(tr);


			var div = $("<div></div>").attr("class","snsdragDropDiv").css("width", "480px;");
			div.append(aaaa, table);
			
			$(".snsdragspan").append(div);
			
		} else {
			$(".snsdragspan").empty();
		}
		summon = !summon;
	});
}


