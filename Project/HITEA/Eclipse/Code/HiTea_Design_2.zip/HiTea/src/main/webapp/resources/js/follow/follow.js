function follower() {
	var pageId = $("#pageId").val();
	$.getJSON("follow.follower?hf_follower_id="+pageId,function(data){
		$(".memberYourPageFollowBut").html("팔로우&nbsp;"+data);
	});
}
function following() {
	var pageId = $("#pageId").val();
	$.getJSON("follow.following?hf_following_hm_id="+pageId,function(data){
		$(".memberYourPageFollowingBut").html("팔로잉&nbsp;"+data);
	});
}
function follower2() {
	var pageId = $("#pageId2").val();
	$.getJSON("follow.follower?hf_follower_id="+pageId,function(data){
		$(".memberMyPageFollowBut").html("팔로우&nbsp;"+data);
	});
}
function following2() {
	var pageId = $("#pageId2").val();
	$.getJSON("follow.following?hf_following_hm_id="+pageId,function(data){
		$(".memberMyPageFollowingBut").html("팔로잉&nbsp;"+data);
	});
}

function followCheck() {
	var shm_id = $("#shm_id").val();
	var pageId = $("#pageId").val();
	
	$.getJSON("follow.followerCheck?hf_following_hm_id="+shm_id+"&hf_follower_id="+pageId,function(data){
		if (data.follow.length == 1) {
			$(".memberYourPageMakingFriendBut").html("팔로우중").css("background","linear-gradient(to right, red, #607D8B38)");
		}else {
			$(".memberYourPageMakingFriendBut").html("팔로우하기").css("background","linear-gradient(to right, #455A6468, #607D8B38)");
			
		}
	});
	
}

function followerRD() {
	var shm_id = $("#shm_id").val();
	var pageId = $("#pageId").val();
	$(".memberYourPageMakingFriendBut").click(function() {
		$.getJSON("follow.followerCheck?hf_following_hm_id="+shm_id+"&hf_follower_id="+pageId,function(data){
			if (data.follow.length == 1) {
				followerDelete(shm_id,pageId);
				follower();
				$(".memberYourPageMakingFriendBut").html("팔로우하기").css("background","linear-gradient(to right, #455A6468, #607D8B38)");
			}else {
				followerReg(shm_id,pageId);
				follower();;
				$(".memberYourPageMakingFriendBut").html("팔로우중").css("background","linear-gradient(to right, red, #607D8B38)");
				
			}
		});
	});
}

function followerReg(shm_id,pageId) {
	$.getJSON("follow.followerReg?hf_following_hm_id="+shm_id+"&hf_follower_id="+pageId,function(data){
	
	});
}
function followerDelete(shm_id,pageId) {
	$.getJSON("follow.followerDelete?hf_following_hm_id="+shm_id+"&hf_follower_id="+pageId,function(data){
	});
}

