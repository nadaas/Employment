package com.jongh.star.sns;

import java.util.List;

public class SNSs {
 private List<SNS> sns;
 public SNSs() {
	// TODO Auto-generated constructor stub
}
public SNSs(List<SNS> sns) {
	super();
	this.sns = sns;
}
public List<SNS> getSns() {
	return sns;
}
public void setSns(List<SNS> sns) {
	this.sns = sns;
}
 
}
