package com.ht.hitea.sns;

public class SNSBeans {

	private SNSBean snsbean;

	public SNSBeans() {
		// TODO Auto-generated constructor stub
	}

	public SNSBeans(SNSBean snsbean) {
		super();
		this.snsbean = snsbean;
	}

	public SNSBean getSnsbean() {
		return snsbean;
	}

	public void setSnsbean(SNSBean snsbean) {
		this.snsbean = snsbean;
	}

}
