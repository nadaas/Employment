package com.ht.hitea.hart;

public class HeartId {
	private String heart_to;
	private String heart_from;
	
	public HeartId() {
		// TODO Auto-generated constructor stub
	}
	public HeartId(String heart_to, String heart_from) {
		super();
		this.heart_to = heart_to;
		this.heart_from = heart_from;
	}
	public String getHeart_to() {
		return heart_to;
	}
	public void setHeart_to(String heart_to) {
		this.heart_to = heart_to;
	}
	public String getHeart_from() {
		return heart_from;
	}
	public void setHeart_from(String heart_from) {
		this.heart_from = heart_from;
	}
	
	
	
}
