package com.ht.hitea.report;

import java.util.List;

public class Reports {
	private List<Report> report;
	public Reports() {
		// TODO Auto-generated constructor stub
	}
	public Reports(List<Report> report) {
		super();
		this.report = report;
	}
	public List<Report> getReport() {
		return report;
	}
	public void setReport(List<Report> report) {
		this.report = report;
	}
	
}
