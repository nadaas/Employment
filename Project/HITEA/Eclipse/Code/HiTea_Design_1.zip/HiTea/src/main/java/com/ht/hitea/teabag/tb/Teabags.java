package com.ht.hitea.teabag.tb;

import java.util.List;

public class Teabags {

	private List<Teabag> teabag;
	
	public Teabags() {
		// TODO Auto-generated constructor stub
	}

	public Teabags(List<Teabag> teabag) {
		super();
		this.teabag = teabag;
	}

	public List<Teabag> getTeabag() {
		return teabag;
	}

	public void setTeabag(List<Teabag> teabag) {
		this.teabag = teabag;
	}

	
	
}
