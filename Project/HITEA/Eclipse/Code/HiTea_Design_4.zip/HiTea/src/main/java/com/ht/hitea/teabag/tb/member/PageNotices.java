package com.ht.hitea.teabag.tb.member;

import java.util.List;

public class PageNotices {
	private List<PageNotice> pagenotice;
	
	public PageNotices() {
		// TODO Auto-generated constructor stub
	}

	public PageNotices(List<PageNotice> pagenotice) {
		super();
		this.pagenotice = pagenotice;
	}

	public List<PageNotice> getPagenotice() {
		return pagenotice;
	}

	public void setPagenotice(List<PageNotice> pagenotice) {
		this.pagenotice = pagenotice;
	}
	
	
}
