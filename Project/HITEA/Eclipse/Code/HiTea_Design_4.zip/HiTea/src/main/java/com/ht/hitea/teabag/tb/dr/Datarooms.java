package com.ht.hitea.teabag.tb.dr;

import java.util.List;

public class Datarooms {
	private List<Dataroom> dataroom;
	
	public Datarooms() {
		// TODO Auto-generated constructor stub
	}

	public Datarooms(List<Dataroom> dataroom) {
		super();
		this.dataroom = dataroom;
	}

	public List<Dataroom> getDataroom() {
		return dataroom;
	}

	public void setDataroom(List<Dataroom> dataroom) {
		this.dataroom = dataroom;
	}
	
	
}
