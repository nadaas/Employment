package com.ht.hitea.hart;

import java.util.List;

public class Harts {
	private List<Hart> hart;
	public Harts() {
		// TODO Auto-generated constructor stub
	}
	public Harts(List<Hart> hart) {
		super();
		this.hart = hart;
	}
	public List<Hart> getHart() {
		return hart;
	}
	public void setHart(List<Hart> hart) {
		this.hart = hart;
	}
	
	
}
